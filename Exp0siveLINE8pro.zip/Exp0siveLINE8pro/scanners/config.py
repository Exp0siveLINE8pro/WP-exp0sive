APP_NAME = "Exp0siveLINE8pro"
VERSION = "1.0.0"

DEFAULT_TIMEOUT = 8
MAX_WORKERS = 8

SAFE_MODE = True   # Passive scanning only
ENABLE_AI = False
