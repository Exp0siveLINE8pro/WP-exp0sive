import requests
import re
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from cve.cve_mapper import map_plugin_to_cves
from utils.risk_score import calculate_risk_score

HEADERS = {
    "User-Agent": "Exp0siveLINE8pro/Advanced-Plugin-Scanner"
}

TIMEOUT = 8
MAX_WORKERS = 8

COMMON_PLUGINS = [
    "elementor",
    "woocommerce",
    "contact-form-7",
    "wordfence",
    "yoast-seo",
    "wpforms",
    "revslider",
    "akismet",
    "wp-file-manager",
    "all-in-one-seo-pack",
    "really-simple-ssl",
    "wp-smush",
    "litespeed-cache"
]

HIGH_RISK_KEYWORDS = ["file", "manager", "backup", "upload"]


def fetch(url):
    try:
        return requests.get(url, headers=HEADERS, timeout=TIMEOUT, allow_redirects=True)
    except Exception:
        return None


def base_result(name):
    return {
        "name": name,
        "detected": False,
        "version": None,
        "risk": "UNKNOWN",
        "confidence": 0.0,
        "heuristics": [],
        "context": [],
        "cves": [],
        "evidence": [],
        "metadata": {
            "scanned_at": datetime.utcnow().isoformat()
        }
    }


def extract_version(text):
    patterns = [
        r"Stable tag:\s*([0-9\.]+)",
        r"Version:\s*([0-9\.]+)"
    ]
    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            return m.group(1)
    return None


def scan_single_plugin(base_url, plugin, context):
    res = base_result(plugin)

    plugin_path = f"/wp-content/plugins/{plugin}/"
    r = fetch(urljoin(base_url, plugin_path))
    if not r or r.status_code not in [200, 403]:
        return None

    res["detected"] = True
    res["confidence"] += 0.4
    res["evidence"].append(plugin_path)

    # Heuristic: risky plugin category
    for k in HIGH_RISK_KEYWORDS:
        if k in plugin:
            res["heuristics"].append("risky_category")
            res["confidence"] += 0.1

    # Context awareness
    if "woocommerce" in context and plugin != "woocommerce":
        res["context"].append("woocommerce_environment")

    # Version detection
    for f in ["readme.txt", f"{plugin}.php"]:
        rf = fetch(urljoin(base_url, plugin_path + f))
        if rf and rf.status_code == 200:
            v = extract_version(rf.text)
            if v:
                res["version"] = v
                res["confidence"] += 0.3
                break

    # CVE + Risk
    res["cves"] = map_plugin_to_cves(plugin, res["version"])
    res["risk"] = calculate_risk_score(res["version"], res["cves"])

    res["confidence"] = min(res["confidence"], 1.0)
    return res


def scan_plugins(target_url):
    print("[*] Advanced plugin scanning started...")

    homepage = fetch(target_url)
    html = homepage.text.lower() if homepage else ""
    context = []
    if "woocommerce" in html:
        context.append("woocommerce")

    results = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as exe:
        tasks = [
            exe.submit(scan_single_plugin, target_url, p, context)
            for p in COMMON_PLUGINS
        ]
        for t in tasks:
            r = t.result()
            if r and r["detected"]:
                results.append(r)
                print(f"[+] {r['name']} | v:{r['version']} | risk:{r['risk']}")

    return results
