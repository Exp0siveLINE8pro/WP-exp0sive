def analyze_security(results):
    insights = []
    score = 0

    core = results.get("core", {})
    plugins = results.get("plugins", [])
    headers = results.get("headers", {})
    signatures = results.get("signatures", [])

    # Core
    if core.get("components", {}).get("xmlrpc", {}).get("enabled"):
        insights.append({
            "component": "wordpress-core",
            "severity": "MEDIUM",
            "analysis": "XML-RPC enabled increases exposure to abuse patterns",
            "reason": "Commonly targeted endpoint"
        })
        score += 10

    # Plugins
    for p in plugins:
        if p["risk"] in ["HIGH", "CRITICAL"]:
            insights.append({
                "component": p["name"],
                "severity": p["risk"],
                "analysis": "High-risk plugin increases attack surface",
                "reason": "Outdated or vulnerable plugin"
            })
            score += 15

        if "risky_category" in p["heuristics"]:
            score += 5

    # Headers
    if headers.get("risk") in ["HIGH", "MEDIUM"]:
        insights.append({
            "component": "security-headers",
            "severity": headers.get("risk"),
            "analysis": "Missing security headers weaken client-side protection",
            "reason": "Browser-based attacks easier"
        })
        score += 10

    # Signatures
    score += len(signatures) * 10

    score = min(score, 100)

    posture = (
        "CRITICAL" if score >= 70 else
        "HIGH" if score >= 40 else
        "MEDIUM" if score >= 20 else
        "LOW"
    )

    return {
        "global_risk_score": score,
        "posture": posture,
        "insights": insights
    }
