import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import argparse

from scanners.wp_core import scan_wp_core
from scanners.plugins import scan_plugins
from scanners.themes import scan_themes
from scanners.headers import scan_headers
from scanners.misconfig import scan_misconfig

from signatures.engine import (
    run_plugin_signatures,
    run_wp_signatures,
    run_header_signatures
)

from core.ai_assistant import analyze_security
from core.reporter import save_reports
from utils.banner import show_banner


def main():
    show_banner()

    parser = argparse.ArgumentParser(
        description="Exp0siveLINE8pro – Advanced WordPress Security Scanner"
    )
    parser.add_argument("-u", "--url", required=True)
    parser.add_argument("-o", "--out", default="reports")
    parser.add_argument("--name", default="exp0sive_report")

    args = parser.parse_args()
    target = args.url.rstrip("/")

    print(f"[+] Target: {target}\n")

    results = {}
    results["core"] = scan_wp_core(target)
    results["plugins"] = scan_plugins(target)
    results["themes"] = scan_themes(target)
    results["headers"] = scan_headers(target)
    results["misconfig"] = scan_misconfig(target)

    results["signatures"] = []
    results["signatures"] += run_plugin_signatures(results["plugins"])
    results["signatures"] += run_wp_signatures(results["core"])
    results["signatures"] += run_header_signatures(results["headers"])

    results["ai_analysis"] = analyze_security(results)

    json_path, html_path = save_reports(
        target, results, args.out, args.name
    )

    print("[✓] Scan completed")
    print(f"[✓] JSON: {json_path}")
    print(f"[✓] HTML: {html_path}")


if __name__ == "__main__":
    main()
